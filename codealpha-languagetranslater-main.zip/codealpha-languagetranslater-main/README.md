# PolyLingo AI – Smart Language Translator

## Overview

PolyLingo AI is a modern, responsive language translation web app. Enter text,
choose source and target languages, and get a clean translation you can copy,
listen to, download or share. Translation runs through a **server-side** function
so API credentials never reach the browser.

## Features

- Two-column translation workspace (stacked on mobile)
- 25+ languages including English, Telugu, Hindi, Tamil, Kannada, Malayalam and more
- Auto-detect source language with a "Detected language" readout
- Searchable language dropdowns and a one-click swap button
- Character counter with a 5,000 character limit, clear button, auto-resizing textarea
- Copy, Text-to-Speech (Web Speech API), Download (.txt) and Share (Web Share API)
- Translation history in localStorage (last 60 items) with copy / reuse / delete
- Quick popular language pairs
- Light and dark mode with persisted preference
- Friendly loading, empty and error states — no raw technical errors
- Accessible semantics, ARIA labels, keyboard support (Ctrl/Cmd + Enter to translate)

## Tech Stack

- React 19, TypeScript, Vite
- TanStack Start + TanStack Router (SSR, server functions)
- Tailwind CSS v4, shadcn/ui, Lucide React
- sonner for toasts
- localStorage for history and theme
- Browser Web Speech API for text-to-speech

## Translation API Setup

Translation is implemented behind a provider abstraction:

- `src/services/translationService.ts` — `translateText` server function (RPC boundary)
- `src/services/translation.server.ts` — provider implementation + isolated mock fallback
- `src/services/translationSchema.ts` — input validation + friendly error mapping

Out of the box the provider calls the managed Lovable AI translation endpoint using
the server-only `LOVABLE_API_KEY`. To swap in Google Cloud Translation or Microsoft
Translator, replace the request inside `translateWithProvider` and read your key from
`process.env["TRANSLATION_API_KEY"]` **inside the handler**.

If no credentials are configured, the app falls back to a clearly labelled
**mock mode** — the UI stays usable and the result is explicitly marked as mock,
never presented as a real translation.

## Environment Variables

Copy `.env.example` and fill in your own values in your hosting provider's
secret manager (never commit real keys):

```
TRANSLATION_API_KEY=your_api_key_here
```

## Installation

```bash
git clone <your-repo-url>
cd polylingo-ai
bun install   # or npm install
```

## Running Locally

```bash
bun run dev   # http://localhost:8080
```

## Deployment

The app builds to a standard TanStack Start output and deploys to Vercel:

1. Push the repository to GitHub.
2. Import the project in Vercel.
3. Add `TRANSLATION_API_KEY` (and any provider config) as Environment Variables.
4. Deploy — Vercel runs `bun run build`.

## Project Structure

```
src/
├── components/       Navbar, Hero, LanguageSelector, SwapButton,
│                     TranslationWorkspace, SourceTextArea, TranslationResult,
│                     TranslateButton, ActionButtons, LanguageShortcuts,
│                     FeatureCards, HowItWorks, Footer, ThemeToggle
├── routes/           index (Translator), history, about, __root
├── services/         translationService, translation.server, translationSchema
├── hooks/            useTranslation, useHistory, useTheme
├── utils/            languageUtils
└── types/            translation.ts
```

## Screenshots

_Add screenshots of the translator, history and about pages here._

## Future Improvements

- Voice input
- Document translation
- Image translation
- Conversation mode
- AI-powered grammar correction
- Pronunciation assistance
- User accounts
- Cloud translation history
