import { useCallback, useEffect, useRef, useState } from "react";
import { speechLocale } from "@/utils/languageUtils";

type Recognition = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onerror: ((event: { error: string }) => void) | null;
  onend: (() => void) | null;
};

function getRecognitionCtor(): (new () => Recognition) | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as {
    SpeechRecognition?: new () => Recognition;
    webkitSpeechRecognition?: new () => Recognition;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function useVoiceInput(onTranscript: (text: string) => void) {
  const [listening, setListening] = useState(false);
  const [supported, setSupported] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const recognitionRef = useRef<Recognition | null>(null);
  const callbackRef = useRef(onTranscript);
  callbackRef.current = onTranscript;

  useEffect(() => {
    setSupported(getRecognitionCtor() !== null);
    return () => recognitionRef.current?.stop();
  }, []);

  const stop = useCallback(() => {
    recognitionRef.current?.stop();
    recognitionRef.current = null;
    setListening(false);
  }, []);

  const start = useCallback(
    (langCode: string) => {
      const Ctor = getRecognitionCtor();
      if (!Ctor) {
        setSupported(false);
        setError("Voice input isn't supported in this browser. Try Chrome or Edge.");
        return;
      }
      setError(null);
      const recognition = new Ctor();
      recognition.lang = speechLocale(langCode);
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.onresult = (event) => {
        let transcript = "";
        for (let i = 0; i < event.results.length; i += 1) {
          transcript += event.results[i]?.[0]?.transcript ?? "";
        }
        callbackRef.current(transcript.trim());
      };
      recognition.onerror = (event) => {
        setError(
          event.error === "not-allowed" || event.error === "service-not-allowed"
            ? "Microphone permission was denied. Allow access and try again."
            : "Voice input stopped unexpectedly. Please try again.",
        );
        setListening(false);
      };
      recognition.onend = () => setListening(false);
      recognitionRef.current = recognition;
      try {
        recognition.start();
        setListening(true);
      } catch {
        setError("Couldn't start voice input. Please try again.");
        setListening(false);
      }
    },
    [],
  );

  return { listening, supported, error, start, stop };
}
