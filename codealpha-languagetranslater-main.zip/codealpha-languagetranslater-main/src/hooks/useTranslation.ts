import { useCallback, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { translateText } from "@/services/translationService";
import { friendlyError } from "@/services/translationSchema";
import type { TranslationResult } from "@/types/translation";

type Status = "idle" | "loading" | "success" | "error";

export function useTranslation() {
  const run = useServerFn(translateText);
  const [status, setStatus] = useState<Status>("idle");
  const [result, setResult] = useState<TranslationResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const inFlight = useRef(false);

  const reset = useCallback(() => {
    setStatus("idle");
    setResult(null);
    setError(null);
  }, []);

  const translate = useCallback(
    async (text: string, sourceLang: string, targetLang: string) => {
      if (inFlight.current) return null;
      if (!text.trim()) {
        setStatus("error");
        setError("Please enter some text to translate.");
        return null;
      }
      inFlight.current = true;
      setStatus("loading");
      setError(null);
      try {
        const response = await run({ data: { text, sourceLang, targetLang } });
        if (!response.ok) {
          setStatus("error");
          setError(friendlyError(response.code));
          return null;
        }
        const payload: TranslationResult = {
          translatedText: response.translatedText,
          detectedLanguage: response.detectedLanguage,
          provider: response.provider,
        };
        setResult(payload);
        setStatus("success");
        return payload;
      } catch {
        setStatus("error");
        setError(friendlyError("network"));
        return null;
      } finally {
        inFlight.current = false;
      }
    },
    [run],
  );

  return { translate, status, result, error, reset, setResult };
}
