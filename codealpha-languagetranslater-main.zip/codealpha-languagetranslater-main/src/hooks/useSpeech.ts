import { useCallback, useEffect, useRef, useState } from "react";
import { speechLocale } from "@/utils/languageUtils";

type SpeechState = "idle" | "speaking" | "paused" | "done";

export function useSpeech() {
  const [state, setState] = useState<SpeechState>("idle");
  const supportedRef = useRef(false);

  useEffect(() => {
    supportedRef.current = typeof window !== "undefined" && "speechSynthesis" in window;
    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const speak = useCallback((text: string, langCode: string) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      throw new Error("unsupported");
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = speechLocale(langCode);
    utterance.onend = () => setState("done");
    utterance.onerror = () => setState("idle");
    window.speechSynthesis.speak(utterance);
    setState("speaking");
  }, []);

  const pause = useCallback(() => {
    if (typeof window === "undefined") return;
    window.speechSynthesis.pause();
    setState("paused");
  }, []);

  const resume = useCallback(() => {
    if (typeof window === "undefined") return;
    window.speechSynthesis.resume();
    setState("speaking");
  }, []);

  const stop = useCallback(() => {
    if (typeof window === "undefined") return;
    window.speechSynthesis.cancel();
    setState("idle");
  }, []);

  return { state, speak, pause, resume, stop };
}
