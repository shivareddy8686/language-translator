import { useCallback, useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useAuth } from "@/lib/auth-context";
import { addCloudHistory, syncLocalHistory } from "@/lib/history.functions";
import type { HistoryItem } from "@/types/translation";

const KEY = "polylingo:history";
const PENDING_KEY = "polylingo:pending";
const LIMIT = 60;

export type SyncState = "offline" | "local" | "syncing" | "synced" | "error";

function read(key: string): HistoryItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as HistoryItem[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function write(key: string, items: HistoryItem[]) {
  try {
    window.localStorage.setItem(key, JSON.stringify(items));
  } catch {
    /* storage unavailable — ignore */
  }
  if (key === KEY) window.dispatchEvent(new Event("polylingo:history-changed"));
}

function toRecord(item: HistoryItem) {
  return {
    sourceText: item.sourceText,
    translatedText: item.translatedText,
    sourceLang: item.sourceLang,
    targetLang: item.targetLang,
    detectedLanguage: item.detectedLanguage ?? null,
    mode: item.mode ?? ("text" as const),
    clientId: item.id,
    createdAt: item.createdAt,
  };
}

/**
 * Local-first translation history with cloud sync.
 * Signed out: everything stays in this browser.
 * Signed in: local records are merged into the account (duplicates skipped)
 * and new translations are written straight to the cloud.
 */
export function useHistory() {
  const { user } = useAuth();
  const upload = useServerFn(addCloudHistory);
  const bulkUpload = useServerFn(syncLocalHistory);
  const [items, setItems] = useState<HistoryItem[]>([]);
  const [syncState, setSyncState] = useState<SyncState>("local");
  const [lastSyncedAt, setLastSyncedAt] = useState<number | null>(null);
  const syncedForUser = useRef<string | null>(null);

  useEffect(() => {
    setItems(read(KEY));
    const sync = () => setItems(read(KEY));
    window.addEventListener("polylingo:history-changed", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("polylingo:history-changed", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  const flushPending = useCallback(async () => {
    if (!user) return;
    const pending = [...read(KEY), ...read(PENDING_KEY)];
    if (pending.length === 0) {
      setSyncState("synced");
      setLastSyncedAt(Date.now());
      return;
    }
    setSyncState("syncing");
    try {
      await bulkUpload({ data: { items: pending.map(toRecord) } });
      write(PENDING_KEY, []);
      setSyncState("synced");
      setLastSyncedAt(Date.now());
      window.dispatchEvent(new Event("polylingo:cloud-changed"));
    } catch {
      setSyncState(navigator.onLine ? "error" : "offline");
    }
  }, [bulkUpload, user]);

  // Merge local history into the account once per session, then keep in sync.
  useEffect(() => {
    if (!user) {
      setSyncState(typeof navigator !== "undefined" && !navigator.onLine ? "offline" : "local");
      syncedForUser.current = null;
      return;
    }
    if (syncedForUser.current === user.id) return;
    syncedForUser.current = user.id;
    void flushPending();
  }, [user, flushPending]);

  useEffect(() => {
    const online = () => {
      if (user) void flushPending();
      else setSyncState("local");
    };
    const offline = () => setSyncState("offline");
    window.addEventListener("online", online);
    window.addEventListener("offline", offline);
    return () => {
      window.removeEventListener("online", online);
      window.removeEventListener("offline", offline);
    };
  }, [user, flushPending]);

  const add = useCallback(
    async (item: Omit<HistoryItem, "id" | "createdAt">) => {
      const entry: HistoryItem = { ...item, id: crypto.randomUUID(), createdAt: Date.now() };
      const next = [entry, ...read(KEY)].slice(0, LIMIT);
      write(KEY, next);
      setItems(next);

      if (!user) return;
      setSyncState("syncing");
      try {
        await upload({ data: toRecord(entry) });
        setSyncState("synced");
        setLastSyncedAt(Date.now());
        window.dispatchEvent(new Event("polylingo:cloud-changed"));
      } catch {
        write(PENDING_KEY, [entry, ...read(PENDING_KEY)].slice(0, 200));
        setSyncState(typeof navigator !== "undefined" && !navigator.onLine ? "offline" : "error");
      }
    },
    [upload, user],
  );

  const remove = useCallback((id: string) => {
    const next = read(KEY).filter((i) => i.id !== id);
    write(KEY, next);
    setItems(next);
  }, []);

  const clear = useCallback(() => {
    write(KEY, []);
    setItems([]);
  }, []);

  return { items, add, remove, clear, syncState, lastSyncedAt, retrySync: flushPending };
}
