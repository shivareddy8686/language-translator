import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const modeEnum = z.enum(["text", "voice", "conversation"]);

const recordSchema = z.object({
  sourceText: z.string().min(1).max(6000),
  translatedText: z.string().min(1).max(20000),
  sourceLang: z.string().min(2).max(8),
  targetLang: z.string().min(2).max(8),
  detectedLanguage: z.string().max(60).nullable().optional(),
  mode: modeEnum.default("text"),
  clientId: z.string().max(60).optional(),
});

const listSchema = z.object({
  query: z.string().max(200).optional(),
  mode: z.enum(["all", "text", "voice", "conversation", "saved"]).default("all"),
  language: z.string().max(8).optional(),
  since: z.string().datetime().optional(),
  until: z.string().datetime().optional(),
  limit: z.number().int().min(1).max(50).default(20),
  offset: z.number().int().min(0).default(0),
});

const SELECT = "id, source_text, translated_text, source_language, target_language, detected_language, translation_mode, created_at, saved_translations(id)";

export const listCloudHistory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => listSchema.parse(input ?? {}))
  .handler(async ({ data, context }) => {
    let q = context.supabase
      .from("translation_history")
      .select(SELECT, { count: "exact" })
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false })
      .range(data.offset, data.offset + data.limit - 1);

    if (data.mode === "saved") q = q.not("saved_translations", "is", null);
    else if (data.mode !== "all") q = q.eq("translation_mode", data.mode);
    if (data.query) {
      const like = `%${data.query.replace(/[%_]/g, "")}%`;
      q = q.or(`source_text.ilike.${like},translated_text.ilike.${like}`);
    }
    if (data.language) {
      q = q.or(`source_language.eq.${data.language},target_language.eq.${data.language}`);
    }
    if (data.since) q = q.gte("created_at", data.since);
    if (data.until) q = q.lte("created_at", data.until);

    const { data: rows, error, count } = await q;
    if (error) throw new Error(error.message);
    return {
      total: count ?? 0,
      items: (rows ?? []).map((row) => ({
        id: row.id,
        sourceText: row.source_text,
        translatedText: row.translated_text,
        sourceLang: row.source_language,
        targetLang: row.target_language,
        detectedLanguage: row.detected_language,
        mode: row.translation_mode,
        createdAt: row.created_at,
        saved: (row.saved_translations ?? []).length > 0,
      })),
    };
  });

export const addCloudHistory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => recordSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("translation_history")
      .insert({
        user_id: context.userId,
        source_text: data.sourceText,
        translated_text: data.translatedText,
        source_language: data.sourceLang,
        target_language: data.targetLang,
        detected_language: data.detectedLanguage ?? null,
        translation_mode: data.mode,
        client_id: data.clientId ?? null,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const syncLocalHistory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        items: z.array(recordSchema.extend({ clientId: z.string().max(60), createdAt: z.number() })).max(200),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    if (data.items.length === 0) return { uploaded: 0 };
    const { error, count } = await context.supabase
      .from("translation_history")
      .upsert(
        data.items.map((item) => ({
          user_id: context.userId,
          source_text: item.sourceText,
          translated_text: item.translatedText,
          source_language: item.sourceLang,
          target_language: item.targetLang,
          detected_language: item.detectedLanguage ?? null,
          translation_mode: item.mode,
          client_id: item.clientId,
          created_at: new Date(item.createdAt).toISOString(),
        })),
        { onConflict: "user_id,client_id", ignoreDuplicates: true, count: "exact" },
      );
    if (error) throw new Error(error.message);
    return { uploaded: count ?? 0 };
  });

export const deleteHistoryItems = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ ids: z.array(z.string().uuid()).min(1).max(200) }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("translation_history")
      .delete()
      .eq("user_id", context.userId)
      .in("id", data.ids);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const clearCloudHistory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { error } = await context.supabase
      .from("translation_history")
      .delete()
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const toggleSavedTranslation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ translationId: z.string().uuid(), saved: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    if (data.saved) {
      const { error } = await context.supabase
        .from("saved_translations")
        .upsert(
          { user_id: context.userId, translation_id: data.translationId },
          { onConflict: "user_id,translation_id", ignoreDuplicates: true },
        );
      if (error) throw new Error(error.message);
    } else {
      const { error } = await context.supabase
        .from("saved_translations")
        .delete()
        .eq("user_id", context.userId)
        .eq("translation_id", data.translationId);
      if (error) throw new Error(error.message);
    }
    return { saved: data.saved };
  });

export const getWorkspaceStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const countOf = async (mode?: "text" | "voice" | "conversation") => {
      let q = context.supabase
        .from("translation_history")
        .select("id", { count: "exact", head: true })
        .eq("user_id", context.userId);
      if (mode) q = q.eq("translation_mode", mode);
      const { count } = await q;
      return count ?? 0;
    };

    const [translations, voice, conversationTranslations] = await Promise.all([
      countOf(),
      countOf("voice"),
      countOf("conversation"),
    ]);
    const { count: saved } = await context.supabase
      .from("saved_translations")
      .select("id", { count: "exact", head: true })
      .eq("user_id", context.userId);
    const { count: conversations } = await context.supabase
      .from("conversations")
      .select("id", { count: "exact", head: true })
      .eq("user_id", context.userId);

    return {
      translations,
      voice,
      conversationTranslations,
      saved: saved ?? 0,
      conversations: conversations ?? 0,
    };
  });

export const globalSearch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ query: z.string().min(1).max(120) }).parse(input))
  .handler(async ({ data, context }) => {
    const like = `%${data.query.replace(/[%_]/g, "")}%`;
    const [translations, conversations] = await Promise.all([
      context.supabase
        .from("translation_history")
        .select(SELECT)
        .eq("user_id", context.userId)
        .or(`source_text.ilike.${like},translated_text.ilike.${like}`)
        .order("created_at", { ascending: false })
        .limit(8),
      context.supabase
        .from("conversations")
        .select("id, title, updated_at")
        .eq("user_id", context.userId)
        .ilike("title", like)
        .order("updated_at", { ascending: false })
        .limit(8),
    ]);

    const items = (translations.data ?? []).map((row) => ({
      id: row.id,
      sourceText: row.source_text,
      translatedText: row.translated_text,
      sourceLang: row.source_language,
      targetLang: row.target_language,
      saved: (row.saved_translations ?? []).length > 0,
    }));

    return {
      translations: items.filter((i) => !i.saved),
      saved: items.filter((i) => i.saved),
      conversations: (conversations.data ?? []).map((c) => ({
        id: c.id,
        title: c.title,
        updatedAt: c.updated_at,
      })),
    };
  });
