import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const tierSchema = z.enum(["fast", "balanced", "advanced"]);
const modeSchema = z.enum(["translate", "practice", "explain", "conversational"]);

export const listAiModels = createServerFn({ method: "GET" }).handler(async () => {
  const { availableTiers } = await import("@/services/conversation.server");
  return availableTiers().map(({ tier, label }) => ({ tier, label }));
});

export const listConversations = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("conversations")
      .select("id, title, source_language, target_language, model, mode, updated_at")
      .eq("user_id", context.userId)
      .order("updated_at", { ascending: false })
      .limit(60);
    if (error) throw new Error(error.message);
    return (data ?? []).map((c) => ({
      id: c.id,
      title: c.title,
      sourceLanguage: c.source_language,
      targetLanguage: c.target_language,
      model: c.model as z.infer<typeof tierSchema>,
      mode: c.mode as z.infer<typeof modeSchema>,
      updatedAt: c.updated_at,
    }));
  });

export const createConversation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        title: z.string().max(120).optional(),
        sourceLanguage: z.string().max(8).default("en"),
        targetLanguage: z.string().max(8).default("te"),
        model: tierSchema.default("balanced"),
        mode: modeSchema.default("conversational"),
      })
      .parse(input ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("conversations")
      .insert({
        user_id: context.userId,
        title: data.title ?? "New conversation",
        source_language: data.sourceLanguage,
        target_language: data.targetLanguage,
        model: data.model,
        mode: data.mode,
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const updateConversation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        title: z.string().min(1).max(120).optional(),
        sourceLanguage: z.string().max(8).optional(),
        targetLanguage: z.string().max(8).optional(),
        model: tierSchema.optional(),
        mode: modeSchema.optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const patch = {
      ...(data.title ? { title: data.title } : {}),
      ...(data.sourceLanguage ? { source_language: data.sourceLanguage } : {}),
      ...(data.targetLanguage ? { target_language: data.targetLanguage } : {}),
      ...(data.model ? { model: data.model } : {}),
      ...(data.mode ? { mode: data.mode } : {}),
    };
    const { error } = await context.supabase
      .from("conversations")
      .update(patch)
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteConversation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("conversations")
      .delete()
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const getConversation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: conversation, error } = await context.supabase
      .from("conversations")
      .select("id, title, source_language, target_language, model, mode, created_at")
      .eq("id", data.id)
      .eq("user_id", context.userId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!conversation) return null;

    const { data: messages, error: messageError } = await context.supabase
      .from("conversation_messages")
      .select("id, role, content, translated_content, language, created_at")
      .eq("conversation_id", data.id)
      .order("created_at", { ascending: true });
    if (messageError) throw new Error(messageError.message);

    return {
      id: conversation.id,
      title: conversation.title,
      sourceLanguage: conversation.source_language,
      targetLanguage: conversation.target_language,
      model: conversation.model as z.infer<typeof tierSchema>,
      mode: conversation.mode as z.infer<typeof modeSchema>,
      createdAt: conversation.created_at,
      messages: (messages ?? []).map((m) => ({
        id: m.id,
        role: m.role as "user" | "assistant" | "system",
        content: m.content,
        translatedContent: m.translated_content,
        language: m.language,
        createdAt: m.created_at,
      })),
    };
  });

export const sendConversationMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        conversationId: z.string().uuid(),
        content: z.string().trim().min(1).max(4000),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { chatCompletion, splitTranslation, systemPrompt, AiError } = await import(
      "@/services/conversation.server"
    );
    const { languageName } = await import("@/utils/languageUtils");

    const { data: conversation, error } = await context.supabase
      .from("conversations")
      .select("id, title, source_language, target_language, model, mode")
      .eq("id", data.conversationId)
      .eq("user_id", context.userId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!conversation) return { ok: false as const, code: "not_found" };

    const { data: history } = await context.supabase
      .from("conversation_messages")
      .select("role, content")
      .eq("conversation_id", conversation.id)
      .order("created_at", { ascending: true })
      .limit(30);

    const { error: insertError, data: userRow } = await context.supabase
      .from("conversation_messages")
      .insert({
        conversation_id: conversation.id,
        role: "user",
        content: data.content,
        language: conversation.source_language,
      })
      .select("id, created_at")
      .single();
    if (insertError) throw new Error(insertError.message);

    try {
      const reply = await chatCompletion(
        [
          {
            role: "system" as const,
            content: systemPrompt(
              conversation.mode as "translate" | "practice" | "explain" | "conversational",
              languageName(conversation.source_language),
              languageName(conversation.target_language),
            ),
          },
          ...(history ?? []).map((m) => ({
            role: m.role === "assistant" ? ("assistant" as const) : ("user" as const),
            content: m.content,
          })),
          { role: "user" as const, content: data.content },
        ],
        conversation.model as "fast" | "balanced" | "advanced",
      );

      const { content, translated } = splitTranslation(reply);
      const { data: assistantRow, error: assistantError } = await context.supabase
        .from("conversation_messages")
        .insert({
          conversation_id: conversation.id,
          role: "assistant",
          content,
          translated_content: translated,
          language: conversation.target_language,
        })
        .select("id, created_at")
        .single();
      if (assistantError) throw new Error(assistantError.message);

      // Title the conversation from its first user message.
      if ((history ?? []).length === 0) {
        await context.supabase
          .from("conversations")
          .update({ title: data.content.slice(0, 60) })
          .eq("id", conversation.id);
      } else {
        await context.supabase
          .from("conversations")
          .update({ updated_at: new Date().toISOString() })
          .eq("id", conversation.id);
      }

      if (translated) {
        await context.supabase.from("translation_history").insert({
          user_id: context.userId,
          source_text: content,
          translated_text: translated,
          source_language: conversation.source_language,
          target_language: conversation.target_language,
          translation_mode: "conversation",
        });
      }

      return {
        ok: true as const,
        userMessage: {
          id: userRow.id,
          role: "user" as const,
          content: data.content,
          translatedContent: null,
          language: conversation.source_language,
          createdAt: userRow.created_at,
        },
        assistantMessage: {
          id: assistantRow.id,
          role: "assistant" as const,
          content,
          translatedContent: translated,
          language: conversation.target_language,
          createdAt: assistantRow.created_at,
        },
      };
    } catch (aiError) {
      const code = aiError instanceof AiError ? aiError.code : "unknown";
      console.error("sendConversationMessage failed", code, aiError);
      return { ok: false as const, code };
    }
  });
