import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/** Optional AI language-learning insight for a completed translation. */
export const getLearningInsight = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        sourceText: z.string().trim().min(1).max(1200),
        translatedText: z.string().trim().min(1).max(2000),
        sourceLanguage: z.string().max(8),
        targetLanguage: z.string().max(8),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { chatCompletion, AiError } = await import("@/services/conversation.server");
    const { languageName } = await import("@/utils/languageUtils");
    try {
      const reply = await chatCompletion(
        [
          {
            role: "system",
            content:
              "You are a concise language tutor. Respond ONLY with compact JSON: " +
              '{"pronunciation":"romanised pronunciation of the translation","meaning":"one-sentence meaning","grammar":"one or two short sentences on grammar/word choice","alternatives":["alternative phrasing", "..."]}. No markdown.',
          },
          {
            role: "user",
            content: `Source (${languageName(data.sourceLanguage)}): ${data.sourceText}\nTranslation (${languageName(
              data.targetLanguage,
            )}): ${data.translatedText}`,
          },
        ],
        "balanced",
      );
      const match = reply.match(/\{[\s\S]*\}/);
      if (!match) return { ok: false as const, code: "empty" };
      const parsed = JSON.parse(match[0]) as {
        pronunciation?: string;
        meaning?: string;
        grammar?: string;
        alternatives?: string[];
      };
      return {
        ok: true as const,
        pronunciation: parsed.pronunciation ?? null,
        meaning: parsed.meaning ?? null,
        grammar: parsed.grammar ?? null,
        alternatives: Array.isArray(parsed.alternatives) ? parsed.alternatives.slice(0, 4) : [],
      };
    } catch (error) {
      const code = error instanceof AiError ? error.code : "unknown";
      console.error("getLearningInsight failed", code, error);
      return { ok: false as const, code };
    }
  });
