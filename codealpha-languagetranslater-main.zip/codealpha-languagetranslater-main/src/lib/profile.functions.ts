import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type Profile = {
  displayName: string | null;
  avatarUrl: string | null;
  defaultSourceLanguage: string;
  defaultTargetLanguage: string;
  themePreference: string;
  voicePreference: string | null;
  autoPlayResponses: boolean;
};

const SELECT =
  "display_name, avatar_url, default_source_language, default_target_language, theme_preference, voice_preference, auto_play_responses";

export const getProfile = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<Profile | null> => {
    const { data, error } = await context.supabase
      .from("profiles")
      .select(SELECT)
      .eq("user_id", context.userId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!data) return null;
    return {
      displayName: data.display_name,
      avatarUrl: data.avatar_url,
      defaultSourceLanguage: data.default_source_language,
      defaultTargetLanguage: data.default_target_language,
      themePreference: data.theme_preference,
      voicePreference: data.voice_preference,
      autoPlayResponses: data.auto_play_responses,
    };
  });

export const updateProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        displayName: z.string().trim().min(1).max(80).optional(),
        avatarUrl: z.string().url().max(500).nullable().optional(),
        defaultSourceLanguage: z.string().max(8).optional(),
        defaultTargetLanguage: z.string().max(8).optional(),
        themePreference: z.enum(["light", "dark", "system"]).optional(),
        voicePreference: z.string().max(80).nullable().optional(),
        autoPlayResponses: z.boolean().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const patch = {
      user_id: context.userId,
      ...(data.displayName !== undefined ? { display_name: data.displayName } : {}),
      ...(data.avatarUrl !== undefined ? { avatar_url: data.avatarUrl } : {}),
      ...(data.defaultSourceLanguage !== undefined
        ? { default_source_language: data.defaultSourceLanguage }
        : {}),
      ...(data.defaultTargetLanguage !== undefined
        ? { default_target_language: data.defaultTargetLanguage }
        : {}),
      ...(data.themePreference !== undefined ? { theme_preference: data.themePreference } : {}),
      ...(data.voicePreference !== undefined ? { voice_preference: data.voicePreference } : {}),
      ...(data.autoPlayResponses !== undefined
        ? { auto_play_responses: data.autoPlayResponses }
        : {}),
    };
    const { error } = await context.supabase
      .from("profiles")
      .upsert(patch, { onConflict: "user_id" });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
