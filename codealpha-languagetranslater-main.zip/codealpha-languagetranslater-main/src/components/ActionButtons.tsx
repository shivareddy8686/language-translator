import { useState } from "react";
import { Copy, Download, Share2, Volume2, VolumeX } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { speechLocale } from "@/utils/languageUtils";

type Props = {
  text: string;
  targetLang: string;
};

export function ActionButtons({ text, targetLang }: Props) {
  const [speaking, setSpeaking] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Translation copied!");
    } catch {
      toast.error("Couldn't copy. Please select and copy manually.");
    }
  };

  const listen = () => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      toast.error("Text-to-speech isn't supported in this browser.");
      return;
    }
    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = speechLocale(targetLang);
    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
    setSpeaking(true);
    toast("Playing translation...");
  };

  const download = () => {
    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `polylingo-${targetLang}.txt`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success("Download started.");
  };

  const share = async () => {
    if (typeof navigator !== "undefined" && "share" in navigator) {
      try {
        await navigator.share({ title: "PolyLingo AI translation", text });
      } catch {
        /* user cancelled */
      }
      return;
    }
    await copy();
    toast("Sharing isn't supported here — copied instead.");
  };

  const actions = [
    { label: "Copy", icon: Copy, onClick: copy },
    {
      label: speaking ? "Stop" : "Listen",
      icon: speaking ? VolumeX : Volume2,
      onClick: listen,
    },
    { label: "Download", icon: Download, onClick: download },
    { label: "Share", icon: Share2, onClick: share },
  ];

  return (
    <div className="flex flex-wrap gap-2">
      {actions.map(({ label, icon: Icon, onClick }) => (
        <Button
          key={label}
          variant="outline"
          size="sm"
          onClick={onClick}
          title={label}
          aria-label={label}
          className="h-9 gap-1.5 rounded-lg bg-card text-xs font-medium"
        >
          <Icon className="size-4" aria-hidden />
          {label}
        </Button>
      ))}
    </div>
  );
}
