import { useEffect, useRef } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MAX_CHARS } from "@/utils/languageUtils";

type Props = {
  value: string;
  onChange: (value: string) => void;
  onClear: () => void;
  onSubmit: () => void;
};

export function SourceTextArea({ value, onChange, onClear, onSubmit }: Props) {
  const ref = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(Math.max(el.scrollHeight, 208), 480)}px`;
  }, [value]);

  return (
    <div className="flex h-full flex-col">
      <div className="mb-2 flex items-center justify-between">
        <label
          htmlFor="source-text"
          className="text-xs font-medium tracking-wide text-muted-foreground uppercase"
        >
          Source text
        </label>
        {value.length > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClear}
            className="h-7 gap-1 px-2 text-xs text-muted-foreground"
          >
            <X className="size-3.5" aria-hidden />
            Clear
          </Button>
        )}
      </div>
      <textarea
        id="source-text"
        ref={ref}
        value={value}
        maxLength={MAX_CHARS}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => {
          if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
            e.preventDefault();
            onSubmit();
          }
        }}
        placeholder="Enter text to translate..."
        aria-describedby="source-counter"
        className="min-h-52 w-full flex-1 resize-none rounded-xl border border-input bg-background px-4 py-3.5 text-base leading-relaxed outline-none transition-shadow duration-200 placeholder:text-muted-foreground focus:border-primary focus:ring-4 focus:ring-ring/20"
      />
      <p id="source-counter" className="mt-2 text-xs text-muted-foreground">
        {value.length} / {MAX_CHARS} characters
        <span className="ml-2 hidden sm:inline">· Ctrl + Enter to translate</span>
      </p>
    </div>
  );
}
