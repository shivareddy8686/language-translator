import { Languages, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

type Props = {
  onClick: () => void;
  loading: boolean;
  disabled: boolean;
};

export function TranslateButton({ onClick, loading, disabled }: Props) {
  return (
    <Button
      onClick={onClick}
      disabled={disabled || loading}
      className="btn-brand h-12 w-full rounded-xl text-base font-semibold sm:w-56"
    >
      {loading ? (
        <>
          <Loader2 className="size-5 animate-spin" aria-hidden />
          Translating...
        </>
      ) : (
        <>
          <Languages className="size-5" aria-hidden />
          Translate
        </>
      )}
    </Button>
  );
}
