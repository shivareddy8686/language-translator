import { Sparkles } from "lucide-react";

export function Hero() {
  return (
    <section className="mx-auto w-full max-w-6xl px-4 pt-12 pb-8 text-center sm:px-6">
      <span className="animate-rise inline-flex items-center gap-2 rounded-full border border-border bg-card px-3.5 py-1.5 text-xs font-medium text-muted-foreground">
        <Sparkles className="size-3.5 text-primary" aria-hidden />
        AI-Powered Language Translation
      </span>
      <h1 className="animate-rise mt-6 text-3xl font-semibold tracking-tight sm:text-4xl md:text-5xl">
        Break Language Barriers with <span className="gradient-text">AI</span>
      </h1>
      <p className="animate-rise mx-auto mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg">
        Translate text instantly across multiple languages with a fast, simple, and
        intelligent translation experience.
      </p>
      <ul
        className="mt-7 flex flex-wrap items-center justify-center gap-2"
        aria-label="Supported language samples"
      >
        {["Hello", "నమస్కారం", "नमस्ते", "Hola", "Bonjour", "こんにちは"].map((word, i) => (
          <li
            key={word}
            className="animate-rise rounded-full border border-border bg-card px-3 py-1.5 text-sm text-muted-foreground"
            style={{ animationDelay: `${i * 90}ms` }}
          >
            {word}
          </li>
        ))}
      </ul>
    </section>
  );
}
