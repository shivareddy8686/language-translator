import { Link } from "@tanstack/react-router";
import { Languages } from "lucide-react";

export function Footer() {
  return (
    <footer className="mt-20 border-t border-border/70 bg-card/40">
      <div className="mx-auto grid w-full max-w-6xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-2">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="btn-brand flex size-8 items-center justify-center rounded-lg">
              <Languages className="size-4" aria-hidden />
            </span>
            <span className="font-semibold tracking-tight">PolyLingo AI</span>
          </div>
          <p className="mt-3 max-w-sm text-sm text-muted-foreground">
            Breaking language barriers with technology.
          </p>
        </div>
        <div className="md:justify-self-end">
          <h2 className="text-sm font-semibold">Explore</h2>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li>
              <Link to="/" search={{ text: undefined, source: undefined, target: undefined }} className="transition-colors hover:text-foreground">
                Translator
              </Link>
            </li>
            <li>
              <Link to="/history" className="transition-colors hover:text-foreground">
                History
              </Link>
            </li>
            <li>
              <Link to="/about" className="transition-colors hover:text-foreground">
                About
              </Link>
            </li>
            <li>
              <a
                href="https://github.com"
                target="_blank"
                rel="noreferrer noopener"
                className="transition-colors hover:text-foreground"
              >
                GitHub
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border/70 px-4 py-5 text-center text-xs text-muted-foreground sm:px-6">
        Built with React, TypeScript &amp; modern web technologies.
      </div>
    </footer>
  );
}
