import { Pause, Play, Square, Volume2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useSpeech } from "@/hooks/useSpeech";

type Props = {
  text: string;
  langCode: string;
  compact?: boolean;
};

export function SpeechControls({ text, langCode, compact = false }: Props) {
  const { state, speak, pause, resume, stop } = useSpeech();

  const play = () => {
    try {
      speak(text, langCode);
    } catch {
      toast.error("Text-to-speech isn't supported in this browser.");
    }
  };

  const size = compact ? "h-8 px-2 text-xs" : "h-9 px-3 text-sm";

  if (state === "speaking") {
    return (
      <div className="flex items-center gap-1">
        <Button variant="outline" onClick={pause} className={`${size} gap-1.5 rounded-lg`}>
          <Pause className="size-4" aria-hidden />
          Pause
        </Button>
        <Button
          variant="ghost"
          onClick={stop}
          aria-label="Stop speech"
          className={`${size} gap-1.5 rounded-lg`}
        >
          <Square className="size-4" aria-hidden />
        </Button>
      </div>
    );
  }

  if (state === "paused") {
    return (
      <div className="flex items-center gap-1">
        <Button variant="outline" onClick={resume} className={`${size} gap-1.5 rounded-lg`}>
          <Play className="size-4" aria-hidden />
          Resume
        </Button>
        <Button
          variant="ghost"
          onClick={stop}
          aria-label="Stop speech"
          className={`${size} gap-1.5 rounded-lg`}
        >
          <Square className="size-4" aria-hidden />
        </Button>
      </div>
    );
  }

  return (
    <Button variant="outline" onClick={play} className={`${size} gap-1.5 rounded-lg`}>
      <Volume2 className="size-4" aria-hidden />
      {state === "done" ? "Listen again" : "Listen"}
    </Button>
  );
}
