import { ArrowLeftRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export function SwapButton({ onClick, disabled }: { onClick: () => void; disabled?: boolean }) {
  return (
    <Button
      variant="outline"
      size="icon"
      onClick={onClick}
      disabled={disabled}
      aria-label="Swap source and target languages"
      title="Swap languages"
      className="size-11 shrink-0 rounded-xl bg-card transition-transform duration-300 hover:rotate-180"
    >
      <ArrowLeftRight className="size-4" aria-hidden />
    </Button>
  );
}
