import { Copy, Globe2, History, Monitor, Volume2, Zap } from "lucide-react";

const FEATURES = [
  {
    icon: Zap,
    title: "Instant Translation",
    body: "Translate text quickly using a powerful translation API.",
  },
  {
    icon: Globe2,
    title: "Multiple Languages",
    body: "Translate across a wide range of global languages.",
  },
  {
    icon: Volume2,
    title: "Text-to-Speech",
    body: "Listen to translated content using built-in speech technology.",
  },
  {
    icon: History,
    title: "Translation History",
    body: "Quickly access your recent translations.",
  },
  {
    icon: Copy,
    title: "Copy & Share",
    body: "Copy or share translations with one click.",
  },
  {
    icon: Monitor,
    title: "Responsive Design",
    body: "Works beautifully across desktop, tablet, and mobile.",
  },
];

export function FeatureCards() {
  return (
    <section className="mx-auto w-full max-w-6xl px-4 pt-20 sm:px-6">
      <h2 className="text-center text-2xl font-semibold tracking-tight sm:text-3xl">
        Everything You Need to Translate
      </h2>
      <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {FEATURES.map(({ icon: Icon, title, body }) => (
          <article key={title} className="surface-card p-6">
            <span className="flex size-10 items-center justify-center rounded-xl bg-accent text-accent-foreground">
              <Icon className="size-5" aria-hidden />
            </span>
            <h3 className="mt-4 font-semibold">{title}</h3>
            <p className="mt-1.5 text-sm text-muted-foreground">{body}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
