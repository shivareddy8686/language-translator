import { AlertCircle, Loader2, Sparkles } from "lucide-react";
import { ActionButtons } from "@/components/ActionButtons";
import { languageName } from "@/utils/languageUtils";
import type { TranslationResult as Result } from "@/types/translation";

type Props = {
  result: Result | null;
  status: "idle" | "loading" | "success" | "error";
  error: string | null;
  sourceLang: string;
  targetLang: string;
};

export function TranslationResult({ result, status, error, sourceLang, targetLang }: Props) {
  return (
    <div className="flex h-full flex-col">
      <div className="mb-2 flex items-center justify-between gap-2">
        <span className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
          Translation
        </span>
        {status === "success" && result && (
          <span className="text-xs text-muted-foreground">
            {result.detectedLanguage ?? languageName(sourceLang)} → {languageName(targetLang)}
          </span>
        )}
      </div>

      <div
        aria-live="polite"
        className="min-h-52 flex-1 rounded-xl border border-border bg-muted/40 px-4 py-3.5"
      >
        {status === "loading" && (
          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="size-4 animate-spin" aria-hidden />
            Translating your text...
          </p>
        )}

        {status === "error" && (
          <p className="flex items-start gap-2 text-sm text-destructive">
            <AlertCircle className="mt-0.5 size-4 shrink-0" aria-hidden />
            {error}
          </p>
        )}

        {status === "idle" && (
          <p className="text-sm text-muted-foreground">Your translation will appear here.</p>
        )}

        {status === "success" && result && (
          <div className="animate-rise space-y-3">
            <p className="text-base leading-relaxed whitespace-pre-wrap">
              {result.translatedText}
            </p>
            {result.detectedLanguage && sourceLang === "auto" && (
              <p className="text-xs text-muted-foreground">
                Detected language: {result.detectedLanguage}
              </p>
            )}
            {result.provider === "mock" && (
              <p className="flex items-center gap-1.5 text-xs text-destructive">
                <AlertCircle className="size-3.5" aria-hidden />
                Mock mode — translation credentials are not configured.
              </p>
            )}
          </div>
        )}
      </div>

      <div className="mt-3 min-h-9">
        {status === "success" && result ? (
          <ActionButtons text={result.translatedText} targetLang={targetLang} />
        ) : (
          <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Sparkles className="size-3.5" aria-hidden />
            Copy, listen, download and share unlock after translating.
          </p>
        )}
      </div>
    </div>
  );
}
