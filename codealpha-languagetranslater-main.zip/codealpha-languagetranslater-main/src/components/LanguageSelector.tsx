import { useState } from "react";
import { Check, ChevronsUpDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { LANGUAGES, TARGET_LANGUAGES, languageName } from "@/utils/languageUtils";
import { cn } from "@/lib/utils";

type Props = {
  value: string;
  onChange: (code: string) => void;
  label: string;
  includeAuto?: boolean;
};

export function LanguageSelector({ value, onChange, label, includeAuto = false }: Props) {
  const [open, setOpen] = useState(false);
  const options = includeAuto ? LANGUAGES : TARGET_LANGUAGES;

  return (
    <div className="w-full">
      <span className="mb-1.5 block text-xs font-medium tracking-wide text-muted-foreground uppercase">
        {label}
      </span>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            aria-label={`${label}: ${languageName(value)}`}
            className="h-11 w-full justify-between rounded-xl bg-card px-3.5 text-sm font-medium"
          >
            <span className="truncate">{languageName(value)}</span>
            <span className="ml-2 flex items-center gap-2">
              <span className="text-xs text-muted-foreground">
                {value === "auto" ? "AUTO" : value.toUpperCase()}
              </span>
              <ChevronsUpDown className="size-4 opacity-50" aria-hidden />
            </span>
          </Button>
        </PopoverTrigger>
        <PopoverContent
          className="w-[--radix-popover-trigger-width] min-w-56 p-0"
          align="start"
        >
          <Command>
            <CommandInput placeholder="Search language..." />
            <CommandList>
              <CommandEmpty>No language found.</CommandEmpty>
              <CommandGroup>
                {options.map((lang) => (
                  <CommandItem
                    key={lang.code}
                    value={`${lang.name} ${lang.code}`}
                    onSelect={() => {
                      onChange(lang.code);
                      setOpen(false);
                    }}
                  >
                    <Check
                      className={cn(
                        "mr-2 size-4",
                        value === lang.code ? "opacity-100" : "opacity-0",
                      )}
                      aria-hidden
                    />
                    <span className="flex-1">{lang.name}</span>
                    <span className="text-xs text-muted-foreground">
                      {lang.code === "auto" ? "AUTO" : lang.code.toUpperCase()}
                    </span>
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
    </div>
  );
}
