import { useState } from "react";
import { Mic, MicOff, Square } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useVoiceInput } from "@/hooks/useVoiceInput";
import { LANGUAGES, AUTO_DETECT } from "@/utils/languageUtils";
import { cn } from "@/lib/utils";

type Props = {
  sourceLang: string;
  onTranscript: (text: string) => void;
  className?: string;
};

export function VoiceInput({ sourceLang, onTranscript, className }: Props) {
  const [voiceLang, setVoiceLang] = useState("en");
  const { listening, supported, error, start, stop } = useVoiceInput(onTranscript);
  const effectiveLang = sourceLang === AUTO_DETECT ? voiceLang : sourceLang;

  const toggle = () => {
    if (listening) {
      stop();
      return;
    }
    start(effectiveLang);
  };

  if (error) toast.error(error, { id: "voice-error" });

  return (
    <div className={cn("flex flex-wrap items-center gap-2", className)}>
      <Button
        type="button"
        variant={listening ? "destructive" : "outline"}
        size="sm"
        onClick={toggle}
        disabled={!supported}
        aria-pressed={listening}
        aria-label={listening ? "Stop listening" : "Start voice input"}
        className="h-9 gap-2 rounded-lg"
      >
        {!supported ? (
          <>
            <MicOff className="size-4" aria-hidden />
            Voice unsupported
          </>
        ) : listening ? (
          <>
            <Square className="size-4" aria-hidden />
            Stop listening
          </>
        ) : (
          <>
            <Mic className="size-4" aria-hidden />
            Speak
          </>
        )}
      </Button>

      {sourceLang === AUTO_DETECT && !listening && supported && (
        <label className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <span className="sr-only sm:not-sr-only">Voice language</span>
          <select
            value={voiceLang}
            onChange={(e) => setVoiceLang(e.target.value)}
            aria-label="Voice recognition language"
            className="h-9 rounded-lg border border-input bg-background px-2 text-xs outline-none focus:border-primary focus:ring-4 focus:ring-ring/20"
          >
            {LANGUAGES.filter((l) => l.code !== AUTO_DETECT).map((l) => (
              <option key={l.code} value={l.code}>
                {l.name}
              </option>
            ))}
          </select>
        </label>
      )}

      {listening && <VoiceWaveform />}
    </div>
  );
}

export function VoiceWaveform() {
  return (
    <span
      className="flex items-center gap-2 rounded-lg bg-primary/10 px-3 py-1.5 text-xs font-medium text-primary"
      aria-live="polite"
    >
      <span className="flex items-end gap-0.5" aria-hidden>
        {[0, 1, 2, 3, 4].map((i) => (
          <span
            key={i}
            className="w-0.5 rounded-full bg-primary"
            style={{
              height: `${6 + (i % 3) * 5}px`,
              animation: `voice-bar 0.9s ease-in-out ${i * 0.1}s infinite`,
            }}
          />
        ))}
      </span>
      Listening… speak now
    </span>
  );
}
