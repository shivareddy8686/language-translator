import { QUICK_PAIRS, languageName } from "@/utils/languageUtils";
import { Button } from "@/components/ui/button";

type Props = {
  onSelect: (source: string, target: string) => void;
};

export function LanguageShortcuts({ onSelect }: Props) {
  return (
    <div className="mt-6">
      <h2 className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
        Popular pairs
      </h2>
      <div className="mt-3 flex flex-wrap gap-2">
        {QUICK_PAIRS.map((pair) => (
          <Button
            key={`${pair.source}-${pair.target}`}
            variant="outline"
            size="sm"
            onClick={() => onSelect(pair.source, pair.target)}
            className="h-9 rounded-full bg-card text-xs font-medium"
          >
            {languageName(pair.source)} → {languageName(pair.target)}
          </Button>
        ))}
      </div>
    </div>
  );
}
