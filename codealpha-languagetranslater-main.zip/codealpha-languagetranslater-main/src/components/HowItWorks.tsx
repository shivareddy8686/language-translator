import { Languages, PenLine, Wand2 } from "lucide-react";

const STEPS = [
  {
    number: "01",
    icon: PenLine,
    title: "Enter Text",
    body: "Enter the text you want to translate.",
  },
  {
    number: "02",
    icon: Languages,
    title: "Choose Languages",
    body: "Select the source and target languages.",
  },
  {
    number: "03",
    icon: Wand2,
    title: "Translate",
    body: "Get your translated result instantly.",
  },
];

export function HowItWorks() {
  return (
    <section className="mx-auto w-full max-w-6xl px-4 pt-20 sm:px-6">
      <h2 className="text-center text-2xl font-semibold tracking-tight sm:text-3xl">
        How It Works
      </h2>
      <ol className="mt-10 grid gap-4 md:grid-cols-3">
        {STEPS.map(({ number, icon: Icon, title, body }) => (
          <li key={number} className="surface-card p-6 transition-transform hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <span className="gradient-text text-3xl font-bold">{number}</span>
              <Icon className="size-5 text-primary" aria-hidden />
            </div>
            <h3 className="mt-4 font-semibold">{title}</h3>
            <p className="mt-1.5 text-sm text-muted-foreground">{body}</p>
          </li>
        ))}
      </ol>
    </section>
  );
}
