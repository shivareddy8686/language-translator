import { Check, CloudOff, Loader2, RefreshCw, TriangleAlert } from "lucide-react";
import type { SyncState } from "@/hooks/useHistory";

type Props = {
  state: SyncState;
  lastSyncedAt: number | null;
  onRetry?: () => void;
};

function relative(ts: number): string {
  const minutes = Math.round((Date.now() - ts) / 60000);
  if (minutes < 1) return "just now";
  if (minutes === 1) return "1 minute ago";
  if (minutes < 60) return `${minutes} minutes ago`;
  return new Date(ts).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
}

export function SyncStatus({ state, lastSyncedAt, onRetry }: Props) {
  const base = "flex items-center gap-1.5 text-xs text-muted-foreground";

  if (state === "syncing")
    return (
      <span className={base} aria-live="polite">
        <Loader2 className="size-3.5 animate-spin" aria-hidden />
        Syncing…
      </span>
    );

  if (state === "offline")
    return (
      <span className={base}>
        <CloudOff className="size-3.5" aria-hidden />
        Offline — saved on this device
      </span>
    );

  if (state === "error")
    return (
      <button type="button" onClick={onRetry} className={`${base} hover:text-foreground`}>
        <TriangleAlert className="size-3.5" aria-hidden />
        Sync failed — retry
        <RefreshCw className="size-3" aria-hidden />
      </button>
    );

  if (state === "synced")
    return (
      <span className={base}>
        <Check className="size-3.5 text-primary" aria-hidden />
        Synced{lastSyncedAt ? ` · ${relative(lastSyncedAt)}` : ""}
      </span>
    );

  return (
    <span className={base}>
      <CloudOff className="size-3.5" aria-hidden />
      Saved on this device
    </span>
  );
}
