import { FileDown } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { exportPdf, type PdfDocument } from "@/lib/pdf";

type Props = {
  document: () => PdfDocument;
  label?: string;
  compact?: boolean;
};

export function PdfExportButton({ document, label = "Export PDF", compact = false }: Props) {
  const run = () => {
    try {
      exportPdf(document());
    } catch (error) {
      toast.error(
        error instanceof Error && error.message === "popup-blocked"
          ? "Allow pop-ups for this site to export a PDF."
          : "Couldn't generate the PDF. Please try again.",
      );
    }
  };

  return (
    <Button
      variant="outline"
      onClick={run}
      className={`${compact ? "h-8 px-2 text-xs" : "h-9 px-3 text-sm"} gap-1.5 rounded-lg`}
    >
      <FileDown className="size-4" aria-hidden />
      {label}
    </Button>
  );
}
