import { useState } from "react";
import { LanguageSelector } from "@/components/LanguageSelector";
import { SwapButton } from "@/components/SwapButton";
import { SourceTextArea } from "@/components/SourceTextArea";
import { TranslateButton } from "@/components/TranslateButton";
import { TranslationResult } from "@/components/TranslationResult";
import { LanguageShortcuts } from "@/components/LanguageShortcuts";
import { useTranslation } from "@/hooks/useTranslation";
import { useHistory } from "@/hooks/useHistory";
import { languageName } from "@/utils/languageUtils";

type Props = {
  initialText?: string | undefined;
  initialSource?: string | undefined;
  initialTarget?: string | undefined;
};

export function TranslationWorkspace({ initialText, initialSource, initialTarget }: Props) {
  const [text, setText] = useState(initialText ?? "");
  const [sourceLang, setSourceLang] = useState(initialSource ?? "auto");
  const [targetLang, setTargetLang] = useState(initialTarget ?? "te");
  const { translate, status, result, error, reset } = useTranslation();
  const { add } = useHistory();

  const handleTranslate = async () => {
    const payload = await translate(text, sourceLang, targetLang);
    if (payload) {
      add({
        sourceText: text,
        translatedText: payload.translatedText,
        sourceLang,
        targetLang,
        // detected label is derived on render
      });
    }
  };

  const swap = () => {
    const nextSource = targetLang;
    const nextTarget =
      sourceLang === "auto" ? (result?.detectedLanguage ? "en" : "en") : sourceLang;
    setSourceLang(nextSource);
    setTargetLang(nextTarget);
    if (result?.translatedText) setText(result.translatedText);
    reset();
  };

  const clearAll = () => {
    setText("");
    reset();
  };

  return (
    <section className="mx-auto w-full max-w-6xl px-4 sm:px-6">
      <div className="surface-card p-4 sm:p-6 lg:p-8">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <LanguageSelector
            label="Source language"
            value={sourceLang}
            onChange={(code) => {
              setSourceLang(code);
              reset();
            }}
            includeAuto
          />
          <div className="flex justify-center sm:pb-0">
            <SwapButton onClick={swap} />
          </div>
          <LanguageSelector
            label="Target language"
            value={targetLang}
            onChange={(code) => {
              setTargetLang(code);
              reset();
            }}
          />
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-2">
          <SourceTextArea
            value={text}
            onChange={setText}
            onClear={clearAll}
            onSubmit={handleTranslate}
          />
          <TranslationResult
            result={result}
            status={status}
            error={error}
            sourceLang={sourceLang}
            targetLang={targetLang}
          />
        </div>

        <div className="mt-6 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
          <TranslateButton
            onClick={handleTranslate}
            loading={status === "loading"}
            disabled={text.trim().length === 0}
          />
          <p className="text-xs text-muted-foreground">
            {languageName(sourceLang)} → {languageName(targetLang)}
          </p>
        </div>

        <LanguageShortcuts
          onSelect={(source, target) => {
            setSourceLang(source);
            setTargetLang(target);
            reset();
          }}
        />
      </div>
    </section>
  );
}
