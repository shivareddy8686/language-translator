export type Language = {
  code: string;
  name: string;
  speech?: string;
};

export type TranslationMode = "text" | "voice" | "conversation";

export type TranslationResult = {
  translatedText: string;
  detectedLanguage: string | null;
  provider: "lovable-ai" | "mock";
};

export type HistoryItem = {
  id: string;
  sourceText: string;
  translatedText: string;
  sourceLang: string;
  targetLang: string;
  detectedLanguage?: string | null;
  mode?: TranslationMode;
  createdAt: number;
};

export type CloudHistoryItem = {
  id: string;
  sourceText: string;
  translatedText: string;
  sourceLang: string;
  targetLang: string;
  detectedLanguage: string | null;
  mode: string;
  createdAt: string;
  saved: boolean;
};
