import type { Language } from "@/types/translation";

export const AUTO_DETECT = "auto";

export const LANGUAGES: Language[] = [
  { code: "auto", name: "Auto Detect" },
  { code: "en", name: "English", speech: "en-US" },
  { code: "te", name: "Telugu", speech: "te-IN" },
  { code: "hi", name: "Hindi", speech: "hi-IN" },
  { code: "ta", name: "Tamil", speech: "ta-IN" },
  { code: "kn", name: "Kannada", speech: "kn-IN" },
  { code: "ml", name: "Malayalam", speech: "ml-IN" },
  { code: "bn", name: "Bengali", speech: "bn-IN" },
  { code: "mr", name: "Marathi", speech: "mr-IN" },
  { code: "gu", name: "Gujarati", speech: "gu-IN" },
  { code: "pa", name: "Punjabi", speech: "pa-IN" },
  { code: "ur", name: "Urdu", speech: "ur-PK" },
  { code: "es", name: "Spanish", speech: "es-ES" },
  { code: "fr", name: "French", speech: "fr-FR" },
  { code: "de", name: "German", speech: "de-DE" },
  { code: "it", name: "Italian", speech: "it-IT" },
  { code: "pt", name: "Portuguese", speech: "pt-PT" },
  { code: "ru", name: "Russian", speech: "ru-RU" },
  { code: "ja", name: "Japanese", speech: "ja-JP" },
  { code: "ko", name: "Korean", speech: "ko-KR" },
  { code: "zh", name: "Chinese", speech: "zh-CN" },
  { code: "ar", name: "Arabic", speech: "ar-SA" },
  { code: "tr", name: "Turkish", speech: "tr-TR" },
  { code: "nl", name: "Dutch", speech: "nl-NL" },
  { code: "vi", name: "Vietnamese", speech: "vi-VN" },
  { code: "id", name: "Indonesian", speech: "id-ID" },
];

export const TARGET_LANGUAGES = LANGUAGES.filter((l) => l.code !== AUTO_DETECT);

export const MAX_CHARS = 5000;

export function getLanguage(code: string): Language | undefined {
  return LANGUAGES.find((l) => l.code === code);
}

export function languageName(code: string): string {
  return getLanguage(code)?.name ?? code.toUpperCase();
}

export function speechLocale(code: string): string {
  return getLanguage(code)?.speech ?? code;
}

export const QUICK_PAIRS: { source: string; target: string }[] = [
  { source: "en", target: "te" },
  { source: "en", target: "hi" },
  { source: "en", target: "es" },
  { source: "en", target: "fr" },
  { source: "en", target: "de" },
  { source: "en", target: "ja" },
];
