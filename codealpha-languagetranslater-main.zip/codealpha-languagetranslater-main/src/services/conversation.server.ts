/**
 * Conversational AI provider abstraction. Server-only.
 *
 * The UI never knows which provider is used: it asks for a tier ("fast",
 * "balanced", "advanced") and this module resolves it to a configured model.
 * Model ids can be overridden with server-side env vars, so swapping provider
 * never requires a frontend change.
 */

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1/chat/completions";

export type ModelTier = "fast" | "balanced" | "advanced";
export type ConversationMode = "translate" | "practice" | "explain" | "conversational";

export class AiError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
  }
}

export type ChatMessage = { role: "user" | "assistant" | "system"; content: string };

/** Configured tiers. Unset env vars simply mean the tier isn't offered. */
export function availableTiers(): { tier: ModelTier; label: string; model: string }[] {
  const map: { tier: ModelTier; label: string; model: string | undefined }[] = [
    { tier: "fast", label: "Fast", model: process.env["AI_MODEL_FAST"] },
    {
      tier: "balanced",
      label: "Balanced",
      model: process.env["AI_MODEL_BALANCED"] ?? "openai/gpt-5.6-sol",
    },
    { tier: "advanced", label: "Advanced", model: process.env["AI_MODEL_ADVANCED"] },
  ];
  return map.filter((m): m is { tier: ModelTier; label: string; model: string } => Boolean(m.model));
}

function resolveModel(tier: ModelTier): string {
  const tiers = availableTiers();
  return (tiers.find((t) => t.tier === tier) ?? tiers[0]!).model;
}

export function systemPrompt(
  mode: ConversationMode,
  sourceLanguage: string,
  targetLanguage: string,
): string {
  const base =
    "You are PolyLingo AI, a multilingual communication assistant. Keep answers concise and useful. " +
    `The user's working languages are ${sourceLanguage} and ${targetLanguage}. ` +
    "Use the conversation history for context: when the user says \"it\", \"that\" or \"make it more polite\", they mean your previous answer.";

  const perMode: Record<ConversationMode, string> = {
    translate:
      ` Act as a precise translator. Reply with the ${targetLanguage} translation first, then a short romanised pronunciation line when the script is non-Latin.`,
    practice:
      ` Act as a friendly language tutor helping the user practise ${targetLanguage}. Reply in simple ${targetLanguage}, then add a short English hint and gently correct mistakes.`,
    explain:
      " Explain meaning, grammar and word choice clearly with short bullet points and one example sentence.",
    conversational:
      ` Have a natural conversation. Reply in ${sourceLanguage} unless the user writes in another language.`,
  };

  return (
    base +
    perMode[mode] +
    ` Always finish with a final line exactly of the form: TRANSLATION: <your reply translated into ${targetLanguage}>.`
  );
}

export async function chatCompletion(
  messages: ChatMessage[],
  tier: ModelTier,
): Promise<string> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new AiError("not_configured", "AI credentials are not configured.");

  let response: Response;
  try {
    response = await fetch(GATEWAY_URL, {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: resolveModel(tier),
        reasoning_effort: "none",
        messages,
      }),
    });
  } catch {
    throw new AiError("network", "AI service unreachable.");
  }

  if (response.status === 429) throw new AiError("rate_limit", "Rate limited.");
  if (response.status === 402) throw new AiError("credits", "Out of credits.");
  if (!response.ok) throw new AiError("provider", `Provider error ${response.status}`);

  const payload = (await response.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  const content = payload.choices?.[0]?.message?.content?.trim();
  if (!content) throw new AiError("empty", "Empty AI response.");
  return content;
}

/** Splits the model reply into the answer and its translation line. */
export function splitTranslation(reply: string): { content: string; translated: string | null } {
  const match = reply.match(/TRANSLATION:\s*([\s\S]*)$/i);
  if (!match) return { content: reply, translated: null };
  return {
    content: reply.slice(0, match.index).trim() || reply.trim(),
    translated: match[1]!.trim() || null,
  };
}
