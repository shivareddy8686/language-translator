import { createServerFn } from "@tanstack/react-start";
import { translateInputSchema } from "./translationSchema";

export const translateText = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => translateInputSchema.parse(data))
  .handler(async ({ data }) => {
    const { translateWithProvider, TranslationError } = await import(
      "./translation.server"
    );
    try {
      const result = await translateWithProvider(
        data.text,
        data.sourceLang,
        data.targetLang,
      );
      return { ok: true as const, ...result };
    } catch (error) {
      const code = error instanceof TranslationError ? error.code : "unknown";
      console.error("translateText failed", code, error);
      return { ok: false as const, code };
    }
  });
