import { z } from "zod";

export const translateInputSchema = z.object({
  text: z.string().trim().min(1).max(5000),
  sourceLang: z.string().min(2).max(8),
  targetLang: z.string().min(2).max(8),
});

export const ERROR_MESSAGES: Record<string, string> = {
  network: "Network issue. Check your connection and try again.",
  rate_limit: "Too many translations right now. Please wait a moment.",
  credits: "Translation service is temporarily unavailable. Please try again later.",
  provider: "Unable to translate this text right now.",
  empty: "Unable to translate this text right now.",
  timeout: "The translation took too long. Please try again.",
  unknown: "Something went wrong. Please try again.",
};

export function friendlyError(code: string): string {
  return ERROR_MESSAGES[code] ?? ERROR_MESSAGES["unknown"]!;
}
