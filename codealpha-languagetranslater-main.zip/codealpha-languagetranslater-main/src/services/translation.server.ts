/**
 * Provider implementation for translation. Server-only.
 *
 * Production path: Lovable AI Gateway (secure, key stays server-side).
 * Fallback path: an explicitly-labelled mock used only when no credentials
 * are configured, so the UI stays usable without pretending to be real.
 */
import { languageName } from "@/utils/languageUtils";
import type { TranslationResult } from "@/types/translation";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1/chat/completions";

export class TranslationError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
  }
}

export async function translateWithProvider(
  text: string,
  sourceLang: string,
  targetLang: string,
): Promise<TranslationResult> {
  const apiKey = process.env["LOVABLE_API_KEY"];

  if (!apiKey) {
    return mockTranslate(text, sourceLang, targetLang);
  }

  const sourceInstruction =
    sourceLang === "auto"
      ? "Detect the source language automatically."
      : `The source language is ${languageName(sourceLang)}.`;

  let response: Response;
  try {
    response = await fetch(GATEWAY_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content:
              "You are a professional translation engine. Translate the user's text faithfully. " +
              sourceInstruction +
              ` Translate into ${languageName(targetLang)}.` +
              ' Respond ONLY with compact JSON: {"translation":"...","detected_language":"<English name of the source language>"}. No markdown, no commentary.',
          },
          { role: "user", content: text },
        ],
      }),
    });
  } catch {
    throw new TranslationError("network", "Translation service unreachable.");
  }

  if (response.status === 429) {
    throw new TranslationError("rate_limit", "Rate limited.");
  }
  if (response.status === 402) {
    throw new TranslationError("credits", "Out of credits.");
  }
  if (!response.ok) {
    throw new TranslationError("provider", `Provider error ${response.status}`);
  }

  const payload = (await response.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  const raw = payload.choices?.[0]?.message?.content?.trim() ?? "";
  if (!raw) throw new TranslationError("empty", "Empty provider response.");

  let translatedText = raw;
  let detectedLanguage: string | null = null;
  const jsonMatch = raw.match(/\{[\s\S]*\}/);
  if (jsonMatch) {
    try {
      const parsed = JSON.parse(jsonMatch[0]) as {
        translation?: string;
        detected_language?: string;
      };
      if (parsed.translation) translatedText = parsed.translation;
      detectedLanguage = parsed.detected_language ?? null;
    } catch {
      /* fall back to raw text */
    }
  }

  return { translatedText, detectedLanguage, provider: "lovable-ai" };
}

/** Clearly isolated development fallback — never presented as a real translation. */
function mockTranslate(
  text: string,
  sourceLang: string,
  targetLang: string,
): TranslationResult {
  return {
    translatedText: `[MOCK MODE — no translation credentials configured]\n${languageName(
      sourceLang,
    )} → ${languageName(targetLang)}\n${text}`,
    detectedLanguage: sourceLang === "auto" ? null : languageName(sourceLang),
    provider: "mock",
  };
}
