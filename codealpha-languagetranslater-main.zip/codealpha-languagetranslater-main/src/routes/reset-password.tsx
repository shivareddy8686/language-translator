import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { KeyRound, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Choose a new password — PolyLingo AI" },
      {
        name: "description",
        content: "Set a new password for your PolyLingo AI translation workspace account.",
      },
      { property: "og:title", content: "Choose a new password — PolyLingo AI" },
      {
        property: "og:description",
        content: "Set a new password for your PolyLingo AI translation workspace account.",
      },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const hash = window.location.hash;
    setReady(hash.includes("type=recovery") || hash.includes("access_token"));
  }, []);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
      toast.success("Password updated");
      navigate({
        to: "/",
        search: { text: undefined, source: undefined, target: undefined },
        replace: true,
      });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Couldn't update the password.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex flex-1 items-center justify-center px-4 py-12 sm:px-6">
        <div className="surface-card w-full max-w-md p-6 sm:p-8">
          <span className="btn-brand mx-auto flex size-11 items-center justify-center rounded-xl">
            <KeyRound className="size-5" aria-hidden />
          </span>
          <h1 className="mt-4 text-center text-2xl font-semibold tracking-tight">
            Choose a new password
          </h1>
          <p className="mt-2 text-center text-sm text-muted-foreground">
            {ready
              ? "Enter a new password for your account."
              : "Open this page from the reset link in your email to continue."}
          </p>
          <form onSubmit={submit} className="mt-6 space-y-4">
            <div>
              <label
                htmlFor="new-password"
                className="text-xs font-medium tracking-wide text-muted-foreground uppercase"
              >
                New password
              </label>
              <input
                id="new-password"
                type="password"
                value={password}
                minLength={8}
                required
                autoComplete="new-password"
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 8 characters"
                className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3.5 text-sm outline-none transition-shadow placeholder:text-muted-foreground focus:border-primary focus:ring-4 focus:ring-ring/20"
              />
            </div>
            <Button
              type="submit"
              disabled={busy}
              className="btn-brand h-11 w-full rounded-xl text-sm font-semibold"
            >
              {busy && <Loader2 className="size-4 animate-spin" aria-hidden />}
              Update password
            </Button>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  );
}
