import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Languages, Loader2, Mail } from "lucide-react";
import { toast } from "sonner";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/auth")({
  validateSearch: (search: Record<string, unknown>) => ({
    redirect: typeof search["redirect"] === "string" ? (search["redirect"] as string) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Sign in — PolyLingo AI Workspace" },
      {
        name: "description",
        content:
          "Sign in to PolyLingo AI to sync your translation history, saved phrases and AI conversations across devices.",
      },
      { property: "og:title", content: "Sign in — PolyLingo AI Workspace" },
      {
        property: "og:description",
        content:
          "Sign in to PolyLingo AI to sync your translation history, saved phrases and AI conversations across devices.",
      },
    ],
  }),
  component: AuthPage,
});

type Mode = "signin" | "signup" | "forgot";

function safePath(value: string | undefined): string {
  if (!value || !value.startsWith("/") || value.startsWith("//")) return "/";
  return value;
}

function AuthPage() {
  const { redirect } = Route.useSearch();
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState<"confirm" | "reset" | null>(null);
  const destination = safePath(redirect);

  useEffect(() => {
    if (!loading && user) {
      navigate({
        to: "/",
        search: { text: undefined, source: undefined, target: undefined },
        replace: true,
      });
    }
  }, [loading, user, navigate]);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    try {
      if (mode === "forgot") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        setSent("reset");
        return;
      }
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}${destination}`,
            ...(displayName.trim() ? { data: { display_name: displayName.trim() } } : {}),
          },
        });
        if (error) throw error;
        if (!data.session) {
          setSent("confirm");
          return;
        }
        toast.success("Welcome to PolyLingo AI!");
        return;
      }
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      toast.success("Signed in");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Something went wrong.");
    } finally {
      setBusy(false);
    }
  };

  const google = async () => {
    setBusy(true);
    try {
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: window.location.origin,
      });
      if (result.error) {
        toast.error("Google sign-in failed. Please try again.");
        return;
      }
      if (result.redirected) return;
      toast.success("Signed in with Google");
    } catch {
      toast.error("Google sign-in failed. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex flex-1 items-center justify-center px-4 py-12 sm:px-6">
        <div className="surface-card w-full max-w-md p-6 sm:p-8">
          <div className="flex flex-col items-center text-center">
            <span className="btn-brand flex size-11 items-center justify-center rounded-xl">
              <Languages className="size-6" aria-hidden />
            </span>
            <h1 className="mt-4 text-2xl font-semibold tracking-tight">
              {mode === "signup"
                ? "Create your workspace"
                : mode === "forgot"
                  ? "Reset your password"
                  : "Welcome back"}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              {mode === "forgot"
                ? "We'll email you a secure link to choose a new password."
                : "Sync history, saved phrases and AI conversations across every device."}
            </p>
          </div>

          {sent ? (
            <div className="mt-6 rounded-xl border border-border bg-muted/40 p-4 text-sm">
              <p className="flex items-center gap-2 font-medium">
                <Mail className="size-4 text-primary" aria-hidden />
                Check your inbox
              </p>
              <p className="mt-2 text-muted-foreground">
                {sent === "confirm"
                  ? `We sent a confirmation link to ${email}. Click it to activate your account.`
                  : `We sent a password reset link to ${email}.`}
              </p>
              <Button
                variant="outline"
                className="mt-4 w-full rounded-lg"
                onClick={() => {
                  setSent(null);
                  setMode("signin");
                }}
              >
                Back to sign in
              </Button>
            </div>
          ) : (
            <>
              <form onSubmit={submit} className="mt-6 space-y-4">
                {mode === "signup" && (
                  <Field
                    id="display-name"
                    label="Display name"
                    type="text"
                    value={displayName}
                    onChange={setDisplayName}
                    placeholder="Ada Lovelace"
                    autoComplete="name"
                  />
                )}
                <Field
                  id="email"
                  label="Email"
                  type="email"
                  value={email}
                  onChange={setEmail}
                  placeholder="you@example.com"
                  autoComplete="email"
                  required
                />
                {mode !== "forgot" && (
                  <Field
                    id="password"
                    label="Password"
                    type="password"
                    value={password}
                    onChange={setPassword}
                    placeholder="At least 8 characters"
                    autoComplete={mode === "signup" ? "new-password" : "current-password"}
                    minLength={8}
                    required
                  />
                )}
                <Button
                  type="submit"
                  disabled={busy}
                  className="btn-brand h-11 w-full rounded-xl text-sm font-semibold"
                >
                  {busy && <Loader2 className="size-4 animate-spin" aria-hidden />}
                  {mode === "signup"
                    ? "Create account"
                    : mode === "forgot"
                      ? "Send reset link"
                      : "Sign in"}
                </Button>
              </form>

              {mode !== "forgot" && (
                <>
                  <div className="my-5 flex items-center gap-3">
                    <span className="h-px flex-1 bg-border" />
                    <span className="text-xs text-muted-foreground uppercase">or</span>
                    <span className="h-px flex-1 bg-border" />
                  </div>
                  <Button
                    variant="outline"
                    onClick={google}
                    disabled={busy}
                    className="h-11 w-full rounded-xl text-sm font-medium"
                  >
                    <GoogleMark />
                    Continue with Google
                  </Button>
                </>
              )}

              <div className="mt-6 space-y-2 text-center text-sm text-muted-foreground">
                {mode === "signin" && (
                  <>
                    <p>
                      New here?{" "}
                      <button
                        type="button"
                        onClick={() => setMode("signup")}
                        className="font-medium text-primary hover:underline"
                      >
                        Create an account
                      </button>
                    </p>
                    <p>
                      <button
                        type="button"
                        onClick={() => setMode("forgot")}
                        className="hover:text-foreground hover:underline"
                      >
                        Forgot your password?
                      </button>
                    </p>
                  </>
                )}
                {mode !== "signin" && (
                  <p>
                    <button
                      type="button"
                      onClick={() => setMode("signin")}
                      className="font-medium text-primary hover:underline"
                    >
                      Back to sign in
                    </button>
                  </p>
                )}
              </div>
            </>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}

function Field({
  id,
  label,
  type,
  value,
  onChange,
  placeholder,
  autoComplete,
  required,
  minLength,
}: {
  id: string;
  label: string;
  type: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  autoComplete?: string;
  required?: boolean;
  minLength?: number;
}) {
  return (
    <div>
      <label htmlFor={id} className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
        {label}
      </label>
      <input
        id={id}
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        autoComplete={autoComplete}
        required={required}
        minLength={minLength}
        className="mt-1.5 h-11 w-full rounded-xl border border-input bg-background px-3.5 text-sm outline-none transition-shadow placeholder:text-muted-foreground focus:border-primary focus:ring-4 focus:ring-ring/20"
      />
    </div>
  );
}

function GoogleMark() {
  return (
    <svg viewBox="0 0 24 24" className="size-4" aria-hidden>
      <path
        fill="#4285F4"
        d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.4a5.5 5.5 0 0 1-2.4 3.6v3h3.9c2.3-2.1 3.6-5.2 3.6-8.8Z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.2 0 5.9-1.1 7.9-2.9l-3.9-3c-1.1.7-2.4 1.2-4 1.2a7 7 0 0 1-6.6-4.8H1.4v3.1A11.9 11.9 0 0 0 12 24Z"
      />
      <path fill="#FBBC05" d="M5.4 14.5a7.1 7.1 0 0 1 0-4.6V6.8H1.4a11.9 11.9 0 0 0 0 10.7l4-3Z" />
      <path
        fill="#EA4335"
        d="M12 4.8c1.8 0 3.3.6 4.6 1.8l3.4-3.4A11.5 11.5 0 0 0 12 0 11.9 11.9 0 0 0 1.4 6.8l4 3.1A7 7 0 0 1 12 4.8Z"
      />
    </svg>
  );
}
