import { createFileRoute, Link } from "@tanstack/react-router";
import { CheckCircle2 } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { HowItWorks } from "@/components/HowItWorks";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About PolyLingo AI – How It Works" },
      {
        name: "description",
        content:
          "Learn how PolyLingo AI translates text securely with a server-side translation API, speech playback and local history.",
      },
      { property: "og:title", content: "About PolyLingo AI – How It Works" },
      {
        property: "og:description",
        content:
          "How PolyLingo AI translates text securely, with speech playback and local history.",
      },
    ],
  }),
  component: AboutPage,
});

const CAPABILITIES = [
  "Translation API integration handled entirely server-side",
  "Support for 25+ global and Indian languages",
  "Text-to-speech playback via the browser Web Speech API",
  "Translation history persisted locally in your browser",
  "Fully responsive layout for desktop, tablet and mobile",
  "Secure API architecture — no keys ever reach the browser",
];

const STACK = [
  { group: "Frontend", items: "React, TypeScript, Vite, TanStack Router" },
  { group: "UI", items: "Tailwind CSS, shadcn/ui, Lucide icons" },
  { group: "Server", items: "TanStack Start server functions" },
  { group: "Translation", items: "Secure server-side translation provider" },
  { group: "Speech", items: "Browser Web Speech API" },
  { group: "Storage", items: "localStorage for history and theme" },
];

function AboutPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <section className="mx-auto w-full max-w-4xl px-4 py-14 sm:px-6">
          <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
            What is <span className="gradient-text">PolyLingo AI</span>?
          </h1>
          <p className="mt-4 text-base leading-relaxed text-muted-foreground">
            PolyLingo AI is a modern language translation tool designed to make
            multilingual communication simple and accessible. Type or paste text, choose
            your languages, and get a clean translation you can copy, listen to, download
            or share — all from one focused workspace.
          </p>

          <ul className="mt-8 grid gap-3 sm:grid-cols-2">
            {CAPABILITIES.map((item) => (
              <li key={item} className="flex items-start gap-2.5 text-sm">
                <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-success" aria-hidden />
                {item}
              </li>
            ))}
          </ul>

          <h2 className="mt-14 text-xl font-semibold tracking-tight">Technology Stack</h2>
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            {STACK.map(({ group, items }) => (
              <div key={group} className="surface-card p-5">
                <h3 className="text-sm font-semibold">{group}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{items}</p>
              </div>
            ))}
          </div>

          <div className="surface-card mt-14 flex flex-col items-start gap-4 p-6 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="font-semibold">Ready to translate?</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Jump into the workspace and try your first language pair.
              </p>
            </div>
            <Button asChild className="btn-brand rounded-xl">
              <Link to="/" search={{ text: undefined, source: undefined, target: undefined }}>Open translator</Link>
            </Button>
          </div>
        </section>
        <div className="pb-6">
          <HowItWorks />
        </div>
      </main>
      <Footer />
    </div>
  );
}
