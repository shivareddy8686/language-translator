import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Hero } from "@/components/Hero";
import { TranslationWorkspace } from "@/components/TranslationWorkspace";
import { FeatureCards } from "@/components/FeatureCards";
import { HowItWorks } from "@/components/HowItWorks";

export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>) => ({
    text: typeof search["text"] === "string" ? (search["text"] as string) : undefined,
    source: typeof search["source"] === "string" ? (search["source"] as string) : undefined,
    target: typeof search["target"] === "string" ? (search["target"] as string) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "language translater" },
      {
        name: "description",
        content:
          "Translate text instantly across multiple languages with PolyLingo AI.",
      },
      { property: "og:title", content: "language translater" },
      {
        property: "og:description",
        content:
          "Translate text instantly across multiple languages with PolyLingo AI.",
      },
    ],
  }),
  component: TranslatorPage,
});

function TranslatorPage() {
  const search = Route.useSearch();
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1 pb-8">
        <Hero />
        <TranslationWorkspace
          initialText={search.text}
          initialSource={search.source}
          initialTarget={search.target}
        />
        <FeatureCards />
        <HowItWorks />
      </main>
      <Footer />
    </div>
  );
}
