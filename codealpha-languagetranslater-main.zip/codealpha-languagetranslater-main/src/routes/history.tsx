import { createFileRoute, Link } from "@tanstack/react-router";
import { Copy, RotateCcw, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useHistory } from "@/hooks/useHistory";
import { languageName } from "@/utils/languageUtils";

export const Route = createFileRoute("/history")({
  head: () => ({
    meta: [
      { title: "Translation History – PolyLingo AI" },
      {
        name: "description",
        content:
          "Review, copy, reuse and manage your recent PolyLingo AI translations.",
      },
      { property: "og:title", content: "Translation History – PolyLingo AI" },
      {
        property: "og:description",
        content: "Review, copy, reuse and manage your recent translations.",
      },
    ],
  }),
  component: HistoryPage,
});

function HistoryPage() {
  const { items, remove, clear } = useHistory();

  const copy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copied to clipboard!");
    } catch {
      toast.error("Couldn't copy that translation.");
    }
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="mx-auto w-full max-w-4xl flex-1 px-4 py-12 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
              Translation History
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Your last {items.length} translation{items.length === 1 ? "" : "s"}, stored
              privately in this browser.
            </p>
          </div>
          {items.length > 0 && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm" className="gap-1.5">
                  <Trash2 className="size-4" aria-hidden />
                  Clear History
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Clear all history?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This permanently removes every saved translation from this browser.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => {
                      clear();
                      toast.success("History cleared.");
                    }}
                  >
                    Clear history
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>

        {items.length === 0 ? (
          <div className="surface-card mt-10 p-10 text-center">
            <p className="font-medium">No translations yet.</p>
            <p className="mt-1.5 text-sm text-muted-foreground">
              Translate something and it will show up here.
            </p>
            <Button asChild className="btn-brand mt-6 rounded-xl">
              <Link to="/" search={{ text: undefined, source: undefined, target: undefined }}>Open translator</Link>
            </Button>
          </div>
        ) : (
          <ul className="mt-8 space-y-4">
            {items.map((item) => (
              <li key={item.id} className="surface-card animate-rise p-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-medium text-primary">
                    {languageName(item.sourceLang)} → {languageName(item.targetLang)}
                  </span>
                  <time
                    className="text-xs text-muted-foreground"
                    dateTime={new Date(item.createdAt).toISOString()}
                  >
                    {new Date(item.createdAt).toLocaleString()}
                  </time>
                </div>
                <p className="mt-3 text-sm text-muted-foreground">{item.sourceText}</p>
                <p className="mt-2 text-base whitespace-pre-wrap">{item.translatedText}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-9 gap-1.5 text-xs"
                    onClick={() => copy(item.translatedText)}
                  >
                    <Copy className="size-4" aria-hidden />
                    Copy
                  </Button>
                  <Button variant="outline" size="sm" className="h-9 gap-1.5 text-xs" asChild>
                    <Link
                      to="/"
                      search={{
                        text: item.sourceText,
                        source: item.sourceLang,
                        target: item.targetLang,
                      }}
                    >
                      <RotateCcw className="size-4" aria-hidden />
                      Reuse
                    </Link>
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-9 gap-1.5 text-xs text-destructive"
                    onClick={() => {
                      remove(item.id);
                      toast.success("Translation deleted.");
                    }}
                  >
                    <Trash2 className="size-4" aria-hidden />
                    Delete
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>
      <Footer />
    </div>
  );
}
